# RealAmogus
A modpack that I use when I play with some friends.

Updates to this modpack will not be very frequent unless there's a new mod we want to use, so you should update them on your own time.
